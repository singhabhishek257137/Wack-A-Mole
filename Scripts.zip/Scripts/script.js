// script.js
document.addEventListener('DOMContentLoaded', () => {
    const holes = document.querySelectorAll('.hole');
    const moles = document.querySelectorAll('.mole');
    const scoreBoard = document.getElementById('score');
    const timeLeft = document.getElementById('time');
    const startButton = document.getElementById('startButton');
    const gameOverScreen = document.getElementById('gameOver');
    const congratsMessage = document.getElementById('congratsMessage');
    const newGameButton = document.getElementById('newGameButton');
    let score = 0;
    let time = 30;
    let gameInterval = null;
    let moleInterval = null;
    
    function randomHole(holes) {
        const index = Math.floor(Math.random() * holes.length);
        return holes[index];
    }

    function popUpMole() {
        const hole = randomHole(holes);
        const mole = hole.querySelector('.mole');
        mole.classList.add('up');
        
        setTimeout(() => {
            mole.classList.remove('up');
            if (time > 0) popUpMole();
        }, Math.random() * 1000 + 500);
    }

    function startGame() {
        score = 0;
        time = 30;
        scoreBoard.textContent = score;
        timeLeft.textContent = time;
        gameOverScreen.classList.add('hidden');
        
        gameInterval = setInterval(() => {
            time--;
            timeLeft.textContent = time;
            if (time <= 0) {
                clearInterval(gameInterval);
                clearInterval(moleInterval);
                endGame();
            }
        }, 1000);
        
        popUpMole();
        moleInterval = setInterval(popUpMole, 1500);
    }

    function endGame() {
        congratsMessage.textContent = `Congratulations! Your final score is ${score}`;
        gameOverScreen.classList.remove('hidden');
    }

    moles.forEach(mole => {
        mole.addEventListener('click', () => {
            if (mole.classList.contains('up')) {
                score++;
                mole.classList.remove('up');
                scoreBoard.textContent = score;
            }
        });
    });

    startButton.addEventListener('click', () => {
        clearInterval(gameInterval);
        clearInterval(moleInterval);
        startGame();
    });

    newGameButton.addEventListener('click', () => {
        startGame();
    });
});
